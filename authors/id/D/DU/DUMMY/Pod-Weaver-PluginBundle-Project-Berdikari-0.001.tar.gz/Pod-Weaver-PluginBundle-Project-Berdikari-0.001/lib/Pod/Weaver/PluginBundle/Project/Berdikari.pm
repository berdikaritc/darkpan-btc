package Pod::Weaver::PluginBundle::Project::Berdikari;

use 5.010001;
use strict;
use warnings;

our $AUTHORITY = 'steven:STEVEN'; # AUTHORITY
our $DATE = '2026-04-07'; # DATE
our $DIST = 'Pod-Weaver-PluginBundle-Project-Berdikari'; # DIST
our $VERSION = '0.001'; # VERSION

use parent qw(Pod::Weaver::PluginBundle::Author::PERLANCAR);

sub mvp_bundle_config {

    my @res;
    for (Pod::Weaver::PluginBundle::Author::PERLANCAR->mvp_bundle_config) {
        if ($_->[0] =~ /\@/) {
            $_->[0] =~ s/\@Author::PERLANCAR/\@Project::Steven/;
        }
        if ($_->[0] =~ m!/Homepage::DefaultCPAN!) {
            push @res, ['@Project::Steven/Steven',
                        Pod::Weaver::PluginBundle::Author::PERLANCAR::_exp('Steven'),
                        {}];
            next;
        } elsif ($_->[0] =~ m!/(Source::DefaultGitHub|Bugs::DefaultRT)!) {
            next;
        }
        push @res, $_;
    }
    @res;
}

1;
# ABSTRACT: Pod weaver config for Berdikari's projects

__END__

=pod

=encoding UTF-8

=head1 NAME

Pod::Weaver::PluginBundle::Project::Berdikari - Pod weaver config for Berdikari's projects

=head1 VERSION

This document describes version 0.001 of Pod::Weaver::PluginBundle::Project::Berdikari (from Perl distribution Pod-Weaver-PluginBundle-Project-Berdikari), released on 2026-04-07.

=head1 SYNOPSIS

In F<weaver.ini>:

 [@Project::Berdikari]

or in F<dist.ini>:

 [PodWeaver]
 config_plugin = @Project::Berdikari

=head1 DESCRIPTION

Basically the same as L<Pod::Weaver::PluginBundle::Author::PERLANCAR> except
that Homepage::DefaultCPAN, Source::DefaultGitHub, and Bugs::DefaultRT are
replaced with Steven.

=for Pod::Coverage .*

=head1 AUTHOR

Steven Haryanto

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2026 by Steven Haryanto.  No
license is granted to other entities.

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=cut
