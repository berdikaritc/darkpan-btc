package Berdikari::Parse::DeliveryReceipt::Common;

use 5.014;
use strict;
use warnings;
use Log::ger;

use Exporter qw(import);
use File::chdir;
use Module::CheckLatestVersion;

our $AUTHORITY = 'darkpan:https://github.com/berdikaritc/darkpan-btc/raw/refs/heads/master'; # AUTHORITY
our $DATE = '2026-04-09'; # DATE
our $DIST = 'Berdikari-Parse-DeliveryReceipt-Common'; # DIST
our $VERSION = '0.038'; # VERSION

check_latest_version({die=>1});

our @EXPORT_OK = qw(
                       convert_receipt_items_to_warehouse_items
                       convert_skus_qtys_to_hashref
                       receipt_filename
                       add_sku
                       check_skus
                       count_receipts_and_items_in_subdirs
                       encode_items_str
                       handle_special_codes
                       parse_items_str
                       parse_items_dirname
                       parse_receipt_filename
                       merge_items

                       %argspecopt_store
                       %argspecopt_receipt_type
                       %argspecopt_delete_unknown_skus
               );

our %SPEC;

our %argspecopt_store = (
    store => {
        schema => ['str*', in=>['berdikari', 'goday']],
        default => 'berdikari',
    },
);

our %argspecopt_delete_unknown_skus = (
    delete_unknown_skus => {
        schema => ['bool*'],
    },
);

our %argspecopt_receipt_type = (
    receipt_type => {
        schema => ['str*', in=>['sale', 'sample', 'gift', 'etc']],
        default => 'sale',
        cmdline_aliases => {
            sample => {is_flag=>1, summary=>'Summary for --receipt-type=sample', code=>sub {$_[0]{receipt_type} = 'sample'}},
            gift   => {is_flag=>1, summary=>'Summary for --receipt-type=gift'  , code=>sub {$_[0]{receipt_type} = 'gift'  }},
            etc    => {is_flag=>1, summary=>'Summary for --receipt-type=etc'   , code=>sub {$_[0]{receipt_type} = 'etc'   }},
        },
    },
);

$SPEC{convert_receipt_items_to_warehouse_items} = {
    v => 1.1,
    summary => "Convert items in receipt to items in warehouse",
    description => <<'MARKDOWN',

SKU's in marketplace and in receipt can be one-product bundle, e.g.:

    DEFDx2 => 3

which will be translated to:


    DEFD => 6

MARKDOWN
    args => {
        receipt_items => {
            schema => 'hash*',
        },
        %argspecopt_store,
    },
    result_naked => 1,
};
sub convert_receipt_items_to_warehouse_items {
    my %args = @_;
    my $receipt_items = ($args{receipt_items} // $args{items}) or die "Please specify receipt_items";
    my $store = $args{store} // 'berdikari';

    my $wh_items = {};
    if ($store eq 'berdikari') {
        for my $key (keys %$receipt_items) {
            my $item = $key;
            if ($item =~ s/\.([A-Z0-9]+)\z//) {
                # suffix e.g. CPORATE.FG -> CPORATE
                my $suffix = $1;
                if ($suffix eq 'B1G1') {
                    $wh_items->{$item} += $receipt_items->{$key} * 2;
                } else {
                    die "Unknown suffix $item.$suffix, please handle this first!";
                }
                next;
            }
            $item =~ s/\A(\d+)x(\w+)\z/${2}x$1/ and log_warn "Converting old convetion $key -> $item"; # fix old convention 2xDEFD -> DEFDx2

            if ($item =~ /^(\w+)x(\d+)$/) {
                $wh_items->{$1} += $receipt_items->{$key} * $2;
            } else {
                $wh_items->{$item} += $receipt_items->{$key};
            }
        }
    } elsif ($store eq 'goday') {
        for my $key (keys %$receipt_items) {
            if    ($key eq 'AB-S/4809'   ) { $wh_items->{ABSTROBERI} += $receipt_items->{$key} }
            elsif ($key eq 'AB-S/14409'  ) { $wh_items->{ABSTROBERI} += $receipt_items->{$key}*3 }
            elsif ($key eq 'AB-S/14409'  ) { $wh_items->{ABSTROBERI} += $receipt_items->{$key}*6 }
            elsif ($key eq 'AB-J/4809'   ) { $wh_items->{ABJAMBU}    += $receipt_items->{$key} }
            elsif ($key eq 'AB-J/14409'  ) { $wh_items->{ABJAMBU}    += $receipt_items->{$key}*3 }
            elsif ($key eq 'AB-J/28809'  ) { $wh_items->{ABJAMBU}    += $receipt_items->{$key}*6 }
            elsif ($key eq 'AB-A/4809'   ) { $wh_items->{ABANGGUR}   += $receipt_items->{$key} }
            elsif ($key eq 'AB-A/14409'  ) { $wh_items->{ABANGGUR}   += $receipt_items->{$key}*3 }
            elsif ($key eq 'AB-A/28809'  ) { $wh_items->{ABANGGUR}   += $receipt_items->{$key}*6 }
            elsif ($key eq 'AB-MIX/14409') {
                $wh_items->{ABANGGUR}   += $receipt_items->{$key}*1;
                $wh_items->{ABJAMBU}    += $receipt_items->{$key}*1;
                $wh_items->{ABSTROBERI} += $receipt_items->{$key}*1; }
            elsif ($key eq 'AB-MIX/28809') {
                $wh_items->{ABANGGUR}   += $receipt_items->{$key}*2;
                $wh_items->{ABJAMBU}    += $receipt_items->{$key}*2;
                $wh_items->{ABSTROBERI} += $receipt_items->{$key}*2; }
        }
    }

    $wh_items;
}

$SPEC{receipt_filename} = {
    v => 1.1,
    summary => "Return filename for receipt",
    description => <<'MARKDOWN',

MARKDOWN
    args => {
        %argspecopt_store,
        %argspecopt_receipt_type,
        gift_pcs => {schema=>'hash*'},
        sample_pcs => {schema=>'hash*'},
        etc_pcs => {schema=>'hash*'},
    },
    result_naked => 1,
};
sub receipt_filename {
    my %args = @_;
    my ($receipt_type, $marketplace, $is_first_page, $order_id, $number,
        $customer, $courier, $receipt_items, $wh_items, $store,
        $promo_code, $gift_pcs, $sample_pcs, $etc_pcs);
    if (exists $args{receipt_type} ) { $receipt_type  = delete $args{receipt_type} } else { $receipt_type = 'sale' }
    if (exists $args{marketplace}  ) { $marketplace   = delete $args{marketplace}  } else { die "Please specify marketplace" }
    if (exists $args{is_first_page}) { $is_first_page = delete $args{is_first_page}} else { die "Please specify is_first_page" }
    if (exists $args{order_id}     ) { $order_id      = delete $args{order_id}     } else { die "Please specify order_id" }
    if (exists $args{number}       ) { $number        = delete $args{number}       } else { die "Please specify number" }
    if (exists $args{customer}     ) { $customer      = delete $args{customer}     } else { die "Please specify customer" }
    if (exists $args{courier}      ) { $courier       = delete $args{courier}      } else { die "Please specify courier" }
    if (exists $args{receipt_items}) { $receipt_items = delete $args{receipt_items}} else { die "Please specify receipt_items" }
    if (exists $args{wh_items}     ) { $wh_items      = delete $args{wh_items}     } else { die "Please specify wh_items" }
    if (exists $args{store}        ) { $store         = delete $args{store}        } else { die "Please specify store" }
    if (exists $args{promo_code}   ) { $promo_code    = delete $args{promo_code}   } else { $promo_code = undef }
    if (exists $args{gift_pcs}     ) { $gift_pcs      = delete $args{gift_pcs}     } else { $gift_pcs = {} }
    if (exists $args{sample_pcs}   ) { $sample_pcs    = delete $args{sample_pcs}   } else { $sample_pcs = {} }
    if (exists $args{etc_pcs}      ) { $etc_pcs       = delete $args{etc_pcs}      } else { $etc_pcs = {} }
    die "Unknown argument(s): ".join(", ", sort keys %args) if keys %args;

    for ($marketplace, $customer, $courier) {
        $_ //= "";
        $_ = lc;
        s/[^A-Za-z0-9_]+/_/g;
    }
    for ($order_id, $number) {
        s/[^A-Za-z0-9_]+/_/g;
    }

    if ($is_first_page) { die "No receipt items" unless keys %$receipt_items }
    for (sort keys %$wh_items) {
        die "Invalid item name: $_, must be uppercase-letters and digits only" unless /^[A-Z][A-Z0-9]+$/;
    }

    my $res_encode = encode_items_str(
        items => $wh_items,
        gift_pcs => $gift_pcs,
        sample_pcs => $sample_pcs,
        etc_pcs => $etc_pcs,
    );
    die "Can't encode items: $res_encode->[0] - $res_encode->[1]" unless $res_encode->[0] == 200;
    my $items_s = $res_encode->[2];

    sprintf "%s-%s-%sekp=%s-no=%s-order=%s-cust=%s-store=%s%s%s.pdf",
        $is_first_page ? "resi" : "page2",
        $marketplace,
        ($receipt_type eq 'sample' ? 'sample=1-' : $receipt_type eq 'gift' ? 'gift=1-' : $receipt_type eq 'etc' ? 'etc=1-' : ''),
        $courier,
        $number,
        $order_id,
        $customer,
        $store,
        (defined $promo_code ? "-code=$promo_code" : ""),
        ($items_s ? "-" : "") . $items_s;
}

$SPEC{add_sku} = {
    v => 1.1,
    summary => "Add SKU item to SKU hash",
    description => <<'MARKDOWN',

MARKDOWN
    args_as => 'array',
    args => {
        skus => {
            schema => 'hash*',
            req => 1,
            pos => 0,
        },
        sku0 => {
            schema => 'str*',
            req => 1,
            pos => 1,
        },
        qty => {
            schema => 'ufloat*',
            req => 1,
            pos => 2,
        },
    },
    result_naked => 1,
};
sub add_sku {
    my ($skus, $sku0, $qty) = @_;

    $sku0 =~ s/\R+//g;
    $sku0 =~ /\A[A-Z][A-Z0-9]+(?:x\d+)?(?:\.[A-Z0-9]+)?\z/ or die "Invalid SKU, must be FOO or FOO1 or FOOx2 or FOO1.FG";

    log_warn "Duplicate SKU" if exists $skus->{$sku0};
    log_trace "add_sku(skus=%s, sku0=%s, qty=%s)", $skus, $sku0, $qty;
    $skus->{$sku0} += $qty;
}

$SPEC{check_skus} = {
    v => 1.1,
    summary => 'Check for unknown/invalid SKUs',
    description => <<'MARKDOWN',
MARKDOWN
    args => {
        wh_items => {schema=>'hash*', req=>1},
        %argspecopt_store,
        %argspecopt_delete_unknown_skus,
    },
};
sub check_skus {
    my %args = @_;
    my $wh_items = $args{wh_items};
    my $store = $args{store};

    my @known_skus = (
        # defend supplements
        "DEFD", # 330iu 15ml
        "DEFDM5", # 330iu 5ml
        "DEFD400", # 400IU 15ml
        "DEFD400M5", # 400IU 5ml
        "DEFIRON", # iron drops 15ml
        "DEFK2DM5", # k2 & d drops 5ml

        # other btc's supplements

        # other people's supplements
        "FRZD",
        "FRZSYR",
        "MBOO",

        # cards
        "CPORATE", # cardporate
        "CBATS", # alphabats
        "CBEETS", # alphabeets
        "CBOATS", # alphaboats
        "CWAR", # road war
        "CTROIKA", # troika
        "CFAID", # first aid
        "CMARK", # marketopia
        "CAIO", # act it out
        "CWSC", # why so cute
        "CWJH", # what just happ
        "CVITD", # vitd card
        "CVITMIN", # vitd card

        # books
        "BVIT", # 360 vitamin book
        "BMIN", # 360 mineral book
        "BMACRO", # 360 macronutrient book
        "BVITDEF", # 360 vitd with defend book

        # jelly
        "ABANGGUR",
        "ABJAMBU",
        "ABSTROBERI",
        "ABAJS3",
        "ABAJS6",

        # t-shirts
        (map { "T1CATYELLOW$_" } (qw/S M L XL XXL/)), #
        (map { "T1CATGREY$_" } (qw/S M L XL XXL/)), #
        (map { "T1RABBITYELLOW$_" } (qw/S M L XL XXL/)), #
        (map { "T1RABBITGREY$_" } (qw/S M L XL XXL/)), #

        # others
        "PIPET18",
    );

    for my $sku (keys %$wh_items) {
        unless (grep { $sku eq $_ } @known_skus) {
            if ($args{delete_unknown_skus}) {
                log_warn "Deleting unknown SKU: $sku";
                delete $wh_items->{$sku};
            } else {
                return [500, "Failed due to unknown SKU '$sku', try running with --delete option to delete unknown SKUs"];
            }
        }
    }

    [200];
}

$SPEC{handle_special_codes} = {
    v => 1.1,
    summary => 'Handle special codes found in receipt text (e.g. add free gift items, etc)',
    args => {
        items => {schema => 'hash*'},
        gift_pcs => {schema => 'hash*'},
        sample_pcs => {schema => 'hash*'},
        etc_pcs => {schema => 'hash*'},
        text => {schema => 'str*'},
        text_raw => {schema => 'str*'},
    },
};
sub handle_special_codes {
    my %args = @_;
    my $items = $args{items};
    my $gift_pcs = $args{gift_pcs} // {};
    my $sample_pcs = $args{sample_pcs} // {};
    my $etc_pcs = $args{etc_pcs} // {};
    my $text = $args{text};
    my $text_raw = $args{text_raw};

    my $code;

    # from: mar 30, 2026: voucher gratis CAIO untuk yang beli pipet, kompensasi jika di dus defend tidak terinclude
    {
        if ($text =~ /BTC988/i && $items->{PIPET18}) {
            $code = "BTC988";
            my $freegift = "CAIO";
            $gift_pcs->{$freegift} += 1;
            $items->{$freegift} += 1;
        }
    }

    # mar-agu 2026
    {
        if ($items->{ABANGGUR} || $items->{ABJAMBU} || $items->{ABSTROBERI}) {
            my $n = ($items->{ABANGGUR} // 0) + ($items->{ABJAMBU} // 0) + ($items->{ABSTROBERI} // 0);
            $code = "ABJELLY66";
            my $freegift = "CAIO";
            $gift_pcs->{$freegift} += $n;
            $items->{$freegift} += $n;
        }
    }

    # apr-mei 2026 free gift utk semua
    {
        if ($items->{DEFD}) {
            if ($text =~ /(BTC\s*471)/i) {
                $code = $1;
                $items   ->{CPORATE}++;
                $gift_pcs->{CPORATE}++;
            } elsif ($text =~ /(BTC\s*472)/i) {
                $code = $1;
                $items   ->{CFAID}++;
                $gift_pcs->{CFAID}++;
            } elsif ($text =~ /(BTC\s*473)/i) {
                $code = $1;
                $items   ->{CWAR}++;
                $gift_pcs->{CWAR}++;
            } elsif ($text =~ /(BTC\s*474)/i) {
                $code = $1;
                $items   ->{TROIKA}++;
                $gift_pcs->{CTROIKA}++;
            } elsif ($text =~ /(BTC\s*475)/i) {
                $code = $1;
                $items   ->{CBATS}++;
                $gift_pcs->{CBATS}++;
            } elsif ($text =~ /(BTC\s*476)/i) {
                $code = $1;
                $items   ->{CBEETS}++;
                $gift_pcs->{CBEETS}++;
            } elsif ($text =~ /(BTC\s*477)/i) {
                $code = $1;
                $items   ->{CAIO}++;
                $gift_pcs->{CAIO}++;
            } else {
                require Array::Sample::WeightedRandom;
                my @card = Array::Sample::WeightedRandom::sample_weighted_random_no_replacement([
                    # berdasarkan posisi stock di gudang efendy per 9 apr 2026
                    ["CAIO",    679],
                    ["CBATS",   464],
                    ["CBEETS",  188],
                    ["CFAID",   227],
                    ["CPORATE", 178],
                    ["CTROIKA",  46],
                    ["CWAR",    246],
                ], 1);
                $code = "BTC470";
                $items   ->{$card[0]}++;
                $gift_pcs->{$card[0]}++;
            }
        }
    }

    [200, "OK", $code];
}

my $description_items_str = <<'MARKDOWN';
Items string is a string containing a dash-separated list of item code, then `=`
sign, then number of pieces. For example:

    DEFD=1-CBATS=1

Parsing this items string will result in this structure:

    {
        items => {DEFD=>1, CBATS=1},
        sales_pcs => {DEFD=>1, CBATS=>1},
        gift_pcs => {},
        sample_pcs => {},
        etc_pcs => {},
    }

Optionally, it can be prefixed with a dash-separated list of item code, then
`_`, then one of `gift`, `sample`, `etc`, then number of pieces. This is for
signifying that a certain number of items are not sales items but
gift/sample/etc items. For example:

    CBATS_gift=1-DEFD=1-CBATS=1

This means the 1 piece of `CBATS` is a gift item, while the rest (`DEFD`) is a
sales item.

Parsing this items string will result in this structure:

    {
        items => {DEFD=>1, CBATS=1},
        sales_pcs => {DEFD=>1},
        gift_pcs => {CBATS=>1},
        sample_pcs => {},
        etc_pcs => {},
    }

Another more complex example:

 CBATS_gift=1-CWAR_sample=1-DEFD=1-CBATS=3-CTROIKA=1-CWAR=1

    {
        items => {DEFD=>1, CBATS=3, CTROIKA=>1, CWAR=>2},
        sales_pcs => {DEFD=>1, CBATS=>2, CTROIKA=>1, CWAR=>1},
        gift_pcs => {CBATS=>1},
        sample_pcs => {CWAR=>1},
        etc_pcs => {},
    }

MARKDOWN

my $description_items_dir = <<'MARKDOWN';
** CURRENT SCHEME **

In an organization scheme, receipt files are organized in directories based on
the items they contain. For example:

    items-DEFD=1/
    items-DEFD=1-CBATS=1/
    items-DEFD=2/
    items-DEFD=2-MBOO=1/
    items-sample-DEFD=1-MBOO=1/
    items-store=goday-DEFD=1-MBOO=1/
    items-CPORATE_gift=1-DEFD=1-CPORATE=1/

where DEFD, MBOO, CBATS, CPORATE are item (SKU) codes. They are followed by `=`
and number of items in the receipt.

    items-sample-DEFD=2-MBOO=2/

`sample`, `gift`, `etc` mean that the items are sample/gift/etc items and not
normal sale items.

    items-CPORATE_gift=1-DEFD=1-CPORATE=1/
    items-CPORATE_gift=1-DEFD=1-CPORATE=2/

`SKU_gift=n`, `SKU_sample=n`, `SKU_etc=n` are codes to mean that a number (`n`)
of particular SKU is a gift/sample/etc items and not normal sale item. In the
second example, one CPORATE item is a sale item and the other one is a gift item
for a total of 2 items.


** OLDER SCHEME (Feb 2025 and earlier)

    0pc/
    1pc/
    ...

In this older scheme, receipt filenames do not contain all the warehouse items,
only DEFD. And they are grouped only on the number of DEFD pieces. To count the
total items, we have to reparse each receipt.

MARKDOWN

$SPEC{parse_items_str} = {
    v => 1.1,
    summary => "Parse string containing list of items, e.g. 'CBATS_gift=1-DEFD=1-CBATS=1'",
    args => {
        str => {
            schema => 'str*',
            req => 1,
            pos => 0,
        },
        is_gift => {
            summary => 'Mark that all items are gift items',
            schema => 'bool*',
        },
        is_sample => {
            summary => 'Mark that all items are sample items',
            schema => 'bool*',
        },
        is_etc => {
            summary => 'Mark that all items are etc items',
            schema => 'bool*',
        },
    },
};
sub parse_items_str {
    my %args = @_;
    my $str = $args{str};
    my $str0 = $str;
    my $is_gift = $args{is_gift};
    my $is_sample = $args{is_sample};
    my $is_etc = $args{is_etc};

    my %gift_pcs;
    my %sample_pcs;
    my %etc_pcs;
    while ($str =~ s/\A-?([A-Z][A-Z0-9]+)_(gift|sample|etc)=(\d+)//g) {
        if ($2 eq 'gift') {
            $gift_pcs{$1} = $3;
        } elsif ($2 eq 'sample') {
            $sample_pcs{$1} = $3;
        } else {
            $etc_pcs{$1} = $3;
        }
    }

    my %items;
    while ($str =~ s/\A-?([A-Z][A-Z0-9]+)=(\d+)//g) {
        $items{$1} = $2;
    }

    my %sales_pcs;
    if ($is_gift) {
        %gift_pcs = %items;
        %sales_pcs = ();
        %sample_pcs = ();
        %etc_pcs = ();
    } elsif ($is_sample) {
        %sample_pcs = %items;
        %sales_pcs = ();
        %gift_pcs = ();
        %etc_pcs = ();
    } elsif ($is_etc) {
        %etc_pcs = %items;
        %sales_pcs = ();
        %gift_pcs = ();
        %sample_pcs = ();
    } else {
        for (keys %items) {
            my $n = $items{$_}
                - ($gift_pcs{$_} // 0)
                - ($sample_pcs{$_} // 0)
                - ($etc_pcs{$_} // 0)
                ;
            die "Incorrect items str '$str0': sales of $_ is negative!"
                if $n < 0;
            if ($n > 0) {
                $sales_pcs{$_} = $n;
            }
        }
    }

    [200, "OK", {
        items => \%items,
        sales_pcs => \%sales_pcs,
        gift_pcs => \%gift_pcs,
        sample_pcs => \%sample_pcs,
        etc_pcs => \%etc_pcs,
        is_gift => $is_gift,
        is_sample => $is_sample,
        is_etc => $is_etc,
    }];
}

$SPEC{parse_receipt_filename} = {
    v => 1.1,
    summary => "Parse receipt filename, e.g. 'resi-shopee-id=123-CBATS_gift=1-DEFD=1-CBATS=1'",
    description => <<MARKDOWN,

MARKDOWN
    args => {
        filename => {
            schema => 'filename*',
            req => 1,
            pos => 0,
        },
    },
};
sub parse_receipt_filename {
    my %args = @_;
    my $file = $args{filename} // $args{file};

    $file =~ s!.+/(.+)!$1!;

    $file =~ /^(resi|page2)                                             # 1) resi or page2
              (?:-(\w+))                                                # 2) marketplace
              (?:-(\w+)-)?                                              # 3) sublabel
              (-(?:[a-z][a-z_0-9]*=[^-]*)(?:-[a-z][a-z_0-9]*=[^-]*)*)?  # 4) params
              (.+?)                                                     # 5) items str
              (\.\w+)?
              \.pdf$
             /x
                 or return [412, "Filename is not /^(resi|page2)-/ PDF or has invalid syntax: $file"];
    my ($resi_or_page2, $marketplace, $sublabel, $params_str, $items_str, undef) = ($1, $2, $3, $4, $5, $6);
    log_trace "resi_or_page2=%s, marketplace=%s, sublabel=%s, params_str=%s, items_str=%s",
        $resi_or_page2, $marketplace, $sublabel, $params_str, $items_str;
    $sublabel //= "";
    $params_str //= "";
    $items_str //= "";

    my %params;
    while ($params_str =~ /-?([^=]+)=([^-]*)/g) {
        $params{$1} = $2;
    }

    my $is_gift   = $sublabel eq 'gift'   || $params_str =~ /^gift=1/;
    my $is_sample = $sublabel eq 'sample' || $params_str =~ /^sample=1/;
    my $is_etc    = $sublabel eq 'etc'    || $params_str =~ /^etc=1/;

    my $res_items = parse_items_str(
        is_gift => $is_gift,
        is_sample => $is_sample,
        is_etc => $is_etc,
        str => $items_str,
    );
    return [500, "Can't parse items str in receipt filename '$file': $res_items->[0] - $res_items->[1]"]
        unless $res_items->[0] == 200;
    [200, "OK", {
        is_first_page => $resi_or_page2 eq 'resi' ? 1:0,
        marketplace => $marketplace,
        sublabel => $sublabel,
        items_str => $items_str,
        %params,
        %{ $res_items->[2] },
    }];
}

$SPEC{parse_items_dirname} = {
    v => 1.1,
    summary => "Parse items directory name",
    description => <<MARKDOWN,

$description_items_dir

This routine parses such directory names.

MARKDOWN
    args => {
        dirname => {
            schema => 'dirname*',
            req => 1,
            pos => 0,
        },
    },
};
sub parse_items_dirname {
    my %args = @_;
    my $dir = $args{dirname} // $args{dir}; # old name

    $dir =~ s!.+/(.+)!$1!;

    $dir =~ /^items
             (-sample|-etc(?:-[a-z]\w*)?)?
             (-(?:[a-z][a-z_0-9]*=[^-]*)(?:-[a-z][a-z_0-9]*=[^-]*)*)?
             (.+)/x
        or return [400, "Dir is not /^items-/: $dir"];
    my ($sublabel, $params_str, $items_str) = ($1, $2, $3);
    log_trace "sublabel=%s, params_str=%s, items_str=%s", $sublabel, $params_str, $items_str;
    $sublabel //= "";
    $params_str //= "";
    $items_str //= "";
    my $is_gift   = $sublabel =~ /^-gift/;
    my $is_sample = $sublabel =~ /^-sample/;
    my $is_etc    = $sublabel =~ /^-etc/;

    my %params;
    while ($params_str =~ /-?([^=]+)=([^-]*)/g) {
        $params{$1} = $2;
    }

    my $res = parse_items_str(
        is_gift => $is_gift,
        is_sample => $is_sample,
        is_etc => $is_etc,
        str => $items_str,
    );
    return $res unless $res->[0] == 200;
    $res->[2]{sublabel} = $sublabel;
    $res->[2]{params} = \%params;
    $res;
}

$SPEC{encode_items_str} = {
    v => 1.1,
    args => {
        items      => {schema=>'hash*'},
        gift_pcs   => {schema=>'hash*'},
        etc_pcs    => {schema=>'hash*'},
        sample_pcs => {schema=>'hash*'},
    },
};
sub encode_items_str {
    my %args = @_;
    my $items0     = $args{items};
    my $gift_pcs   = $args{gift_pcs} // {};
    my $etc_pcs    = $args{etc_pcs} // {};
    my $sample_pcs = $args{sample_pcs} // {};

    my $items = { DEFD=>0, %$items0 };

    my $res0 = join(
        "-",
        (map {"${_}_gift=$gift_pcs->{$_}"} sort keys %$gift_pcs),
        (map {"${_}_sample=$sample_pcs->{$_}"} sort keys %$sample_pcs),
        (map {"${_}_etc=$etc_pcs->{$_}"} sort keys %$etc_pcs),
        (map {"$_=$items->{$_}"} sort {
            ($a eq "DEFD" ? 0 : 1) <=> ($b eq "DEFD" ? 0 : 1) ||
                $a cmp $b
        } keys %$items),
    );

    [200, "OK", $res0];
}

$SPEC{count_receipts_and_items_in_subdirs} = {
    v => 1.1,
    summary => "Count receipt files and total items in items subdirectories",
    description => <<MARKDOWN,

$description_items_dir

This routine returns the number of receipts as well as items from all the items
subdirectories.

MARKDOWN
    args => {
        dir => {
            summary => 'Directory that contains the items subdirs, default to current directory',
            schema => 'dirname::default_curdir_abs*',
            pos => 0,
        },
        include_subdir_pat => {
            summary => 'Only include subdirectories matching this pattern',
            schema => 're_from_str*',
            tags => ['category:filtering'],
        },
        include_store => {
            summary => 'Only include receipts from this store',
            schema => 'str*',
            tags => ['category:filtering'],
        },
        include_marketplace => {
            summary => 'Only include receipts from this marketplace',
            schema => 'str*',
            tags => ['category:filtering'],
        },
        count_receipt_items => {
            summary => 'Whether to also count receipt SKUs',
            schema => 'bool*',
            description => <<'MARKDOWN',

By default, only warehouse items (SKUs) are counted. This only requires us to
parse the items subdirs, e.g.:

    items-DEFD=1/
    items-DEFD=1-FRZD=1/
    ...

and does not require us to re-parse each receipt files, as the items subdirs
already list items as warehouse items.

However, if we want to count receipt items (e.g. because the SKU coding for some
stores are different), then we need to re-parse each receipt files.

MARKDOWN
        },
    },
    result_naked => 1,
};
sub count_receipts_and_items_in_subdirs {
    my %args = @_;

    my $tot_files = 0;
    my %stores;
    my %pcs_sales;
    my %pcs_sample;
    my %pcs_gift;
    my %pcs_etc; # e.g. resending due to error, etc
    my %receipts_by_store;
    my %receipts_by_marketplace;
    my %receipts_by_courier;

    my %receipt_pcs_sales;
    my %receipt_pcs_sample;
    my %receipt_pcs_gift;
    my %receipt_pcs_etc;

    my $dir = $args{dir} // $CWD;
    {
        local $CWD = $dir;

        for my $subdir (glob "*") {
            next unless -d $subdir;
            if (defined $args{include_subdir_pat}) {
                unless ($subdir =~ $args{include_subdir_pat}) {
                    log_info "Subdir $subdir does not match $args{include_subdir_pat}, skipped";
                    next;
                }
            }

            my $store;

            if ($subdir =~ /^(\d+)pc(-.+)?/) {

                # OLD SCHEME, FEB 2025 AND EARLIER

                $store = "berdikari";
                my ($num_defd, $label) = ($1, $2);
                $label //= "";
                my $files = 0;
                my @files;
                {
                    $store = "-"; # store name not put in directory name
                    local $CWD = $subdir;
                    @files = glob "resi-*.pdf";
                    $files = @files;

                    next if defined($args{include_store}) && $store ne $args{include_store};

                    for my $file (@files) {
                        my ($marketplace) = $file =~ /^resi-([^-]+)-/;

                        next if defined($args{include_marketplace}) && $marketplace ne $args{include_marketplace};

                        my $resparse;
                        if ($marketplace eq 'shopee') {
                            require Berdikari::Parse::DeliveryReceipt::Shopee; # circular require?
                            $resparse = Berdikari::Parse::DeliveryReceipt::Shopee::parse_delivery_receipt(
                                filename => $file,
                            );
                        } elsif ($marketplace eq 'tiktokshop') {
                            require Berdikari::Parse::DeliveryReceipt::TiktokShop; # circular require?
                            $resparse = Berdikari::Parse::DeliveryReceipt::TiktokShop::parse_delivery_receipt(
                                filename => $file,
                            );
                        } elsif ($marketplace eq 'tokopedia') {
                            require Berdikari::Parse::DeliveryReceipt::Tokopedia; # circular require?
                            $resparse = Berdikari::Parse::DeliveryReceipt::Tokopedia::parse_delivery_receipt(
                                filename => $file,
                            );
                        } else {
                            die "Unknown marketplace '$marketplace' in receipt '$file'";
                        }
                        die "Can't parse receipt '$file': $resparse->[0] - $resparse->[1]"
                            unless $resparse->[0] == 200;

                        my $whitems = convert_receipt_items_to_warehouse_items(items => $resparse->[2]{items});

                        $receipts_by_store{$store}++;
                        $receipts_by_marketplace{$marketplace}++;
                        $receipts_by_courier{lc $resparse->[2]{courier}}++;

                        for my $whitem (keys %$whitems) {
                            if ($label =~ /etc/) {
                                $pcs_etc{$store}{$whitem} += $whitems->{$whitem};
                            } elsif ($label =~ /sample/) {
                                $pcs_sample{$store}{$whitem} += $whitems->{$whitem};
                            } elsif ($label =~ /gift|fg/) {
                                $pcs_gift{$store}{$whitem} += $whitems->{$whitem};
                            } else {
                                $pcs_sales{$store}{$whitem} += $whitems->{$whitem};
                            }
                        }
                    } # for $file
                }
                $tot_files += $files;

            } else {

                my $res2 = parse_items_dirname(dir => $subdir);
                die "Can't parse items subdir '$subdir': $res2->[0] - $res2->[1]"
                    unless $res2->[0] == 200;

                $store = $res2->[2]{params}{store} // 'berdikari';
                # for receipts in directory where param override_receipt_items
                # is set to true, this means that we decide to not send items
                # according to stated in receipts. the actual receipt items that
                # are sent are put in receipt_items.json file
                my $override_receipt_items = $res2->[2]{params}{override_receipt_items};

                next if defined($args{include_store}) && $store ne $args{include_store};

                my $files = 0;
                my @files;
                {
                    local $CWD = $subdir;
                    @files = glob "resi-*.pdf";
                    $files = @files;
                }
                if ($files == 0) {
                    log_debug "Items subdir $subdir does not have any resi-* PDF files, skipped";
                    next;
                }

                {
                    local $CWD = $subdir;
                    for my $file (@files) {
                        $receipts_by_store{$store}++;

                        my ($marketplace) = $file =~ /^resi-(tiktokshop|shopee|tokopedia)-/
                            or die "Can't parse filename $file: unknown marketplace, must be resi-{shopee,tiktokshop,tokopedia}-";

                        next if defined($args{include_marketplace}) && $marketplace ne $args{include_marketplace};
                        $receipts_by_marketplace{$marketplace}++;

                        $tot_files++;

                        my $courier;
                        if ($file =~ /\Wekp=([^-]+)/) {
                            $courier = $1;
                        } else {
                            if ($marketplace eq 'shopee') {
                                log_warn "Setting default courier=spx for $file";
                                $courier = "spx";
                            } elsif ($marketplace eq 'tiktokshop') {
                                log_warn "Setting default courier=j_t for $file";
                                $courier = "j_t";
                            } else {
                                die "Can't get courier (ekp=...) for file $file";
                            }
                        }
                        $receipts_by_courier{$courier}++;

                        if ($args{count_receipt_items}) {
                            my $ritems;

                            if ($override_receipt_items) {
                                require JSON::MaybeXS;
                                open my $fh, "<", "receipt_items.json"
                                    or die "Can't open receipt_items.json in $subdir/: $!";
                                my $json = do { local $/; scalar <$fh> };
                                $ritems = JSON::MaybeXS::decode_json($json);

                            } else {
                                my $resparse;
                                if ($marketplace eq 'shopee') {
                                    require Berdikari::Parse::DeliveryReceipt::Shopee; # circular require?
                                    $resparse = Berdikari::Parse::DeliveryReceipt::Shopee::parse_delivery_receipt(
                                        filename => $file,
                                        store => $store,
                                    );
                                } elsif ($marketplace eq 'tiktokshop') {
                                    require Berdikari::Parse::DeliveryReceipt::TiktokShop; # circular require?
                                    $resparse = Berdikari::Parse::DeliveryReceipt::TiktokShop::parse_delivery_receipt(
                                        filename => $file,
                                        store => $store,
                                    );
                                } else {
                                    # as of jul 2025, tokopedia has been merged into tiktokshop
                                    die "Unsupported marketplace '$marketplace'";
                                }
                                die "Can't parse receipt '$file': $resparse->[0] - $resparse->[1]"
                                    unless $resparse->[0] == 200;

                                $ritems = $resparse->[2]{items};
                            }

                            for my $ritem (keys %$ritems) {
                                if ($res2->[2]{is_etc}) {
                                    $receipt_pcs_etc{$store}{$ritem} += $ritems->{$ritem};
                                } elsif ($res2->[2]{is_gift}) {
                                    $receipt_pcs_gift{$store}{$ritem} += $ritems->{$ritem};
                                } elsif ($res2->[2]{is_sample}) {
                                    $receipt_pcs_sample{$store}{$ritem} += $ritems->{$ritem};
                                } else {
                                    $receipt_pcs_sales{$store}{$ritem} += $ritems->{$ritem};
                                }
                            }

                        }
                    } # for files
                } # scope CWD for files

                log_trace "Subdirectory $subdir ($files file(s))";
                #use DD; dd $res2;
                for my $item (sort keys %{ $res2->[2]{items} }) {
                    my $n = $res2->[2]{items}{$item};

                    if ($res2->[2]{is_sample}) {

                        if (my $n_gift = $res2->[2]{sample_pcs}{$item}) {
                            $n -= $n_gift;
                            die "BUG: negative amount after deducted by sample=$n_gift" if $n < 0;
                            $pcs_gift{$store}{$item} += $files * $n_gift;
                        }
                        $pcs_sample{$store}{$item} += $files * $n if $n > 0;

                    } elsif ($res2->[2]{is_etc}) {

                        if (my $n_gift = $res2->[2]{gift_pcs}{$item}) {
                            $n -= $n_gift;
                            die "BUG: negative amount after deducted by gift=$n_gift" if $n < 0;
                            $pcs_gift{$store}{$item} += $files * $n_gift;
                        }
                        $pcs_etc{$store}{$item} += $files * $n if $n > 0;

                    } else {

                        if (my $n_sample = $res2->[2]{sample_pcs}{$item}) {
                            $n -= $n_sample;
                            die "BUG: negative amount after deducted by sample=$n_sample" if $n < 0;
                            $pcs_sample{$store}{$item} += $files * $n_sample;
                        }
                        if (my $n_gift = $res2->[2]{gift_pcs}{$item}) {
                            $n -= $n_gift;
                            die "BUG: negative amount after deducted by gift=$n_gift" if $n < 0;
                            $pcs_gift{$store}{$item} += $files * $n_gift;
                        }
                        if (my $n_etc = $res2->[2]{etc_pcs}{$item}) {
                            $n -= $n_etc;
                            die "BUG: negative amount after deducted by etc=$n_etc" if $n < 0;
                            $pcs_etc{$store}{$item} += $files * $n_etc;
                        }
                        $pcs_sales{$store}{$item} += $files * $n if $n > 0;

                    }
                }

            } # NEW SCHEME

            $store //= "berdikari";
            $stores{$store}++;

        } # for $subdir
    }

    [200, "OK", {
        num_receipts => $tot_files,

        stores => [sort keys %stores],

        num_items_sales => \%pcs_sales,
        num_items_sample => \%pcs_sample,
        num_items_gift => \%pcs_gift,
        num_items_etc => \%pcs_etc,

        num_receipt_items_sales => \%receipt_pcs_sales,
        num_receipt_items_sample => \%receipt_pcs_sample,
        num_receipt_items_gift => \%receipt_pcs_gift,
        num_receipt_items_etc => \%receipt_pcs_etc,

        num_receipts_by_store => \%receipts_by_store,
        num_receipts_by_marketplace => \%receipts_by_marketplace,
        num_receipts_by_courier => \%receipts_by_courier,
    }];
}

$SPEC{convert_skus_qtys_to_hashref} = {
    v => 1.1,
    summary => "Convert a pair of SKU's and QTY's arrays to hash of SKUs and quantities",
    description => <<'MARKDOWN',

It's certainly possible to have multiple order items that have the same SKU,
because we can assign the same SKU code for different products in the
marketplace.

MARKDOWN
    args_as => 'array',
    args => {
        skus => {
            schema => 'array*',
            req => 1,
            pos => 0,
        },
        qtys => {
            schema => 'array*',
            req => 1,
            pos => 1,
        },
    },
    result_naked => 1,
    result => {
        schema => 'hash*',
    },
};
sub convert_skus_qtys_to_hashref {
    my ($skus, $qtys) = @_;

    my $hash = {};
    for (0 .. $#{$skus}) {
        my ($sku, $qty) = ($skus->[$_], $qtys->[$_]);
        $hash->{$sku} //= 0;
        $hash->{$sku} += $qty;
    }

    $hash;
}

$SPEC{merge_items} = {
    v => 1.1,
    summary => "Merge several responses of parse_receipt_filename()'s",
    description => <<'MARKDOWN',

MARKDOWN
    args_as => 'array',
    args => {
        responses => {
            schema => ['array*', of=>'array*'], # array of envres's
            req => 1,
            pos => 0,
            slurpy => 1,
        },
    },
    result_naked => 1,
    result => {
        schema => 'hash*',
    },
};
sub merge_items {
    my $res = {};

    for my $envres (@_) {
        my $items = $envres->[2]{items};
        for my $sku (keys %$items) {
            $res->{items}{$sku} += $items->{$sku};
        }
        my $sales_pcs = $envres->[2]{sales_pcs};
        for my $sku (keys %$sales_pcs) {
            $res->{sales_pcs}{$sku} += $sales_pcs->{$sku};
        }
        my $gift_pcs = $envres->[2]{gift_pcs};
        for my $sku (keys %$gift_pcs) {
            $res->{gift_pcs}{$sku} += $gift_pcs->{$sku};
        }
        my $sample_pcs = $envres->[2]{sample_pcs};
        for my $sku (keys %$sample_pcs) {
            $res->{sample_pcs}{$sku} += $sample_pcs->{$sku};
        }
        my $etc_pcs = $envres->[2]{etc_pcs};
        for my $sku (keys %$etc_pcs) {
            $res->{etc_pcs}{$sku} += $etc_pcs->{$sku};
        }
    }

    $res;
}

1;
# ABSTRACT: Count receipt files and total items in items subdirectories

__END__

=pod

=encoding UTF-8

=head1 NAME

Berdikari::Parse::DeliveryReceipt::Common - Count receipt files and total items in items subdirectories

=head1 VERSION

This document describes version 0.038 of Berdikari::Parse::DeliveryReceipt::Common (from Perl distribution Berdikari-Parse-DeliveryReceipt-Common), released on 2026-04-09.

=head1 TERMINOLOGY

=head2 items directory

Synonyms: items dir

A directory named:

 /^items-
   (-sample|-etc(?:-[a-z]\w*)?)?                             # 1) sublabel
   (-(?:[a-z][a-z_0-9]*=[^-]*)(?:-[a-z][a-z_0-9]*=[^-]*)*)?  # 2) parameters
   (.+)                                                      # 3) items string
 /x

The directory contains receipt files with identical item set (technically
speaking, using the same items string). Some examples:

 items-DEFD=1
 items-CBATS_gift=1-DEF=1-CBATS=1

B<Sublabel>. A sublabel can mark all the items as C<gitt>, C<sample>, or <Cetc>
items instead of normal sales items. Example:

 items-sample-CBATS=1-CPORATE=1

B<Parameters>. Parameters are dash-separated of key-value pairs for various
purposes. Keys must be lowercased, to differentiate with items. Examples:

 items-store=berdikari-DEFD=1

=head2 items string

A string containing serialized list of items and quantities. Examples:
C<DEFD=1>, C<DEFD=1-PIPET18=2>. Optionally it can also be prefixed by a list of
items that are, instead of normal sales items, C<gift> items, C<sample> items,
or C<etc> items, using C<SKU_gift=n>, C<SKU_sample=n>, C<SKU_etc=n>. Examples:
C<CBATS_gift=1-DEFD=1-CBATS=1> (this means all CBATS are gift items),
C<CBATS_gift=1-DEFD=1-CBATS=3> (this means one CBATS piece is a gift item while
the rest is sales items.

=head2 receipt file

Receipt files are named like this:

 /^resi-
   (\w+)                                                     # 1) marketplace namee
   (-sample|-etc(?:-[a-z]\w*)?)?                             # 2) sublabel
   (-(?:[a-z][a-z_0-9]*=[^-]*)(?:-[a-z][a-z_0-9]*=[^-]*)*)?  # 3) parameters
   (.+)                                                      # 3) items string
 /x

Receipt files are usually grouped into items directories to ease processing.

See also: L</items directory>.

=head2 receipt item

SKU code that is stated in receipt. It does not necessarily map one to one to
warehouse item which is the actual SKU stored in the warehouse. For example, a
receipt can contain these items:

 DEFDx2 => 1
 MBOO.FG => 2

When parsing a receipt, the module converts receipt items to L</warehouse item>s
so packing department can easily see which and how many items are to be assigned
to fulfill a receipt. For example, the above receipt items can be converted to
the following warehouse items:

 DEFD => 2
 MBOO => 2
 CBOOK1 => 2

=head2 SKU code

Synonyms: item

This module restrict warehouse SKU codes to:

 /^[A-Z][A-Z0-9]+$/

Examples:

 DEFD
 PIPET18

But receipt SKU codes can contain optional suffixes:

 # bundle of the same item
 /x\d+$/
 DEFDx2
 DEFDx3

 # dot suffix for additional meaning
 /\.[A-Z0-9]+$/
 DEFD.B1G1
 DEFD.B2G1
 DEFD.FG
 DEFD.FREEGIFT

=head2 warehouse item

SKU code for item in the warehouse. They do not necessarily map one to one to
receipt items.

See also: L<receipt item>

=head1 FUNCTIONS


=head2 add_sku

Usage:

 add_sku($skus, $sku0, $qty) -> any

Add SKU item to SKU hash.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<$qty>* => I<ufloat>

(No description)

=item * B<$sku0>* => I<str>

(No description)

=item * B<$skus>* => I<hash>

(No description)


=back

Return value:  (any)



=head2 check_skus

Usage:

 check_skus(%args) -> [$status_code, $reason, $payload, \%result_meta]

Check for unknownE<sol>invalid SKUs.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<delete_unknown_skus> => I<bool>

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)

=item * B<wh_items>* => I<hash>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 convert_receipt_items_to_warehouse_items

Usage:

 convert_receipt_items_to_warehouse_items(%args) -> any

Convert items in receipt to items in warehouse.

SKU's in marketplace and in receipt can be one-product bundle, e.g.:

 DEFDx2 => 3

which will be translated to:

 DEFD => 6

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<receipt_items> => I<hash>

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Return value:  (any)



=head2 convert_skus_qtys_to_hashref

Usage:

 convert_skus_qtys_to_hashref($skus, $qtys) -> hash

Convert a pair of SKU's and QTY's arrays to hash of SKUs and quantities.

It's certainly possible to have multiple order items that have the same SKU,
because we can assign the same SKU code for different products in the
marketplace.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<$qtys>* => I<array>

(No description)

=item * B<$skus>* => I<array>

(No description)


=back

Return value:  (hash)



=head2 count_receipts_and_items_in_subdirs

Usage:

 count_receipts_and_items_in_subdirs(%args) -> any

Count receipt files and total items in items subdirectories.

I<* CURRENT SCHEME *>

In an organization scheme, receipt files are organized in directories based on
the items they contain. For example:

 items-DEFD=1/
 items-DEFD=1-CBATS=1/
 items-DEFD=2/
 items-DEFD=2-MBOO=1/
 items-sample-DEFD=1-MBOO=1/
 items-store=goday-DEFD=1-MBOO=1/
 items-CPORATE_gift=1-DEFD=1-CPORATE=1/

where DEFD, MBOO, CBATS, CPORATE are item (SKU) codes. They are followed by C<=>
and number of items in the receipt.

 items-sample-DEFD=2-MBOO=2/

C<sample>, C<gift>, C<etc> mean that the items are sample/gift/etc items and not
normal sale items.

 items-CPORATE_gift=1-DEFD=1-CPORATE=1/
 items-CPORATE_gift=1-DEFD=1-CPORATE=2/

C<SKU_gift=n>, C<SKU_sample=n>, C<SKU_etc=n> are codes to mean that a number (C<n>)
of particular SKU is a gift/sample/etc items and not normal sale item. In the
second example, one CPORATE item is a sale item and the other one is a gift item
for a total of 2 items.

** OLDER SCHEME (Feb 2025 and earlier)

 0pc/
 1pc/
 ...

In this older scheme, receipt filenames do not contain all the warehouse items,
only DEFD. And they are grouped only on the number of DEFD pieces. To count the
total items, we have to reparse each receipt.

This routine returns the number of receipts as well as items from all the items
subdirectories.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<count_receipt_items> => I<bool>

Whether to also count receipt SKUs.

By default, only warehouse items (SKUs) are counted. This only requires us to
parse the items subdirs, e.g.:

 items-DEFD=1/
 items-DEFD=1-FRZD=1/
 ...

and does not require us to re-parse each receipt files, as the items subdirs
already list items as warehouse items.

However, if we want to count receipt items (e.g. because the SKU coding for some
stores are different), then we need to re-parse each receipt files.

=item * B<dir> => I<dirname::default_curdir_abs>

Directory that contains the items subdirs, default to current directory.

=item * B<include_marketplace> => I<str>

Only include receipts from this marketplace.

=item * B<include_store> => I<str>

Only include receipts from this store.

=item * B<include_subdir_pat> => I<re_from_str>

Only include subdirectories matching this pattern.


=back

Return value:  (any)



=head2 encode_items_str

Usage:

 encode_items_str(%args) -> [$status_code, $reason, $payload, \%result_meta]

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<etc_pcs> => I<hash>

(No description)

=item * B<gift_pcs> => I<hash>

(No description)

=item * B<items> => I<hash>

(No description)

=item * B<sample_pcs> => I<hash>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 handle_special_codes

Usage:

 handle_special_codes(%args) -> [$status_code, $reason, $payload, \%result_meta]

Handle special codes found in receipt text (e.g. add free gift items, etc).

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<etc_pcs> => I<hash>

(No description)

=item * B<gift_pcs> => I<hash>

(No description)

=item * B<items> => I<hash>

(No description)

=item * B<sample_pcs> => I<hash>

(No description)

=item * B<text> => I<str>

(No description)

=item * B<text_raw> => I<str>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 merge_items

Usage:

 merge_items($responses, ...) -> hash

Merge several responses of parse_receipt_filename()'s.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<$responses>* => I<array[array]>

(No description)


=back

Return value:  (hash)



=head2 parse_items_dirname

Usage:

 parse_items_dirname(%args) -> [$status_code, $reason, $payload, \%result_meta]

Parse items directory name.

I<* CURRENT SCHEME *>

In an organization scheme, receipt files are organized in directories based on
the items they contain. For example:

 items-DEFD=1/
 items-DEFD=1-CBATS=1/
 items-DEFD=2/
 items-DEFD=2-MBOO=1/
 items-sample-DEFD=1-MBOO=1/
 items-store=goday-DEFD=1-MBOO=1/
 items-CPORATE_gift=1-DEFD=1-CPORATE=1/

where DEFD, MBOO, CBATS, CPORATE are item (SKU) codes. They are followed by C<=>
and number of items in the receipt.

 items-sample-DEFD=2-MBOO=2/

C<sample>, C<gift>, C<etc> mean that the items are sample/gift/etc items and not
normal sale items.

 items-CPORATE_gift=1-DEFD=1-CPORATE=1/
 items-CPORATE_gift=1-DEFD=1-CPORATE=2/

C<SKU_gift=n>, C<SKU_sample=n>, C<SKU_etc=n> are codes to mean that a number (C<n>)
of particular SKU is a gift/sample/etc items and not normal sale item. In the
second example, one CPORATE item is a sale item and the other one is a gift item
for a total of 2 items.

** OLDER SCHEME (Feb 2025 and earlier)

 0pc/
 1pc/
 ...

In this older scheme, receipt filenames do not contain all the warehouse items,
only DEFD. And they are grouped only on the number of DEFD pieces. To count the
total items, we have to reparse each receipt.

This routine parses such directory names.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<dirname>* => I<dirname>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 parse_items_str

Usage:

 parse_items_str(%args) -> [$status_code, $reason, $payload, \%result_meta]

Parse string containing list of items, e.g. 'CBATS_gift=1-DEFD=1-CBATS=1'.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<is_etc> => I<bool>

Mark that all items are etc items.

=item * B<is_gift> => I<bool>

Mark that all items are gift items.

=item * B<is_sample> => I<bool>

Mark that all items are sample items.

=item * B<str>* => I<str>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 parse_receipt_filename

Usage:

 parse_receipt_filename(%args) -> [$status_code, $reason, $payload, \%result_meta]

Parse receipt filename, e.g. 'resi-shopee-id=123-CBATS_gift=1-DEFD=1-CBATS=1'.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<filename>* => I<filename>

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 receipt_filename

Usage:

 receipt_filename(%args) -> any

Return filename for receipt.

This function is not exported by default, but exportable.

Arguments ('*' denotes required arguments):

=over 4

=item * B<etc_pcs> => I<hash>

(No description)

=item * B<gift_pcs> => I<hash>

(No description)

=item * B<receipt_type> => I<str> (default: "sale")

(No description)

=item * B<sample_pcs> => I<hash>

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Return value:  (any)

=head1 AUTHOR

Steven Haryanto

=head1 CONTRIBUTORS

=for stopwords perlancar Steven Haryanto

=over 4

=item *

perlancar <perlancar@cpan.org>

=item *

Steven Haryanto <stevenharyanto@gmail.com>

=item *

Steven Haryanto <stevenptbtc@gmail.com>

=back

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2026, 2025 by Steven Haryanto.  No
license is granted to other entities.

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=cut
