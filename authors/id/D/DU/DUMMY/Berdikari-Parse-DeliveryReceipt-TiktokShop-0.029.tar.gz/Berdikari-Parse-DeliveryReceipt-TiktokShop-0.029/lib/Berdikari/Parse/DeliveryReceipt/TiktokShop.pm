package Berdikari::Parse::DeliveryReceipt::TiktokShop;

use 5.014;
use strict;
use warnings;
use Log::ger;

use Berdikari::Parse::DeliveryReceipt::Common qw(
                                                    convert_skus_qtys_to_hashref
                                                    receipt_filename
                                                    convert_receipt_items_to_warehouse_items
                                                    handle_special_codes
                                                    encode_items_str
                                                    check_skus
                                                    %argspecopt_store
                                                    %argspecopt_receipt_type
                                                    %argspecopt_delete_unknown_skus
                                            );
use IPC::System::Options 'readpipe', -log=>1;
use Module::CheckLatestVersion;
use Perinci::Object;

our $AUTHORITY = 'darkpan:https://github.com/berdikaritc/darkpan-btc/raw/refs/heads/master'; # AUTHORITY
our $DATE = '2026-05-25'; # DATE
our $DIST = 'Berdikari-Parse-DeliveryReceipt-TiktokShop'; # DIST
our $VERSION = '0.029'; # VERSION

check_latest_version({log_level=>'warn', die=>1});

sub _strip_ws { $_[0] =~ s/\s+//gr }

our %SPEC;

$SPEC{parse_delivery_receipt} = {
    v => 1.1,
    summary => "Parse TiktokShop delivery receipt (resi pengiriman)",
    description => <<'MARKDOWN',

For older versions of receipts: Because TiktokShop's delivery receipt needs to
be OCR'ed first, this utility will first produce a `*.ocrmypdf.pdf` file if it
does not yet exist.

For newer versions: by default, no OCR-ing is done because it's no longer
needed.

MARKDOWN
    args => {
        filename => {
            schema => 'filename::exists*',
            req => 1,
            pos => 0,
        },
        ocr => {
            schema => 'bool*',
        },
        %argspecopt_store,
        %argspecopt_delete_unknown_skus,
    },
    deps => {
        all => [
            {prog => 'ocrmypdf'},
            {prog => 'pdftotext'},
        ],
    },
};
sub parse_delivery_receipt {
    my %args = @_;
    my $filename = $args{filename} or return [400, "Please specify filename"];
    my $store = $args{store} // 'berdikari';
    my $delete_unknown_skus = $args{delete_unknown_skus};

    return [412, "Please supply a .pdf file"] unless $filename =~ /\.pdf\z/;

    my $isocr = $filename =~ /\.ocrmypdf.pdf\z/;

    # XXX why won't info+ log statements show? even with this
    #use Log::ger::Util;
    #Log::ger::Util::set_level("trace");

    my $text_raw;

    if (!$isocr && $args{ocr}) {
        (my $ocr_filename = $filename) =~ s/\.pdf\z/.ocrmypdf.pdf/;
        if (!(-f $ocr_filename) || (-M $ocr_filename) > (-M $filename)) {
            log_info "(Re-)OCR-ing file %s first to %s ...", $filename, $ocr_filename;
            unlink $ocr_filename;
            system "ocrmypdf --force-ocr '$filename' '$ocr_filename'";
        }
        $text_raw = `pdftotext -raw '$ocr_filename' - 2>/dev/null`;
    } else {
        $text_raw = `pdftotext -raw '$filename' - 2>/dev/null`;
    }

    my ($receipt_id) = $text_raw =~ /^(
                                         (?:JX\d{10}+)|
                                         (?:JX\d+(?:\s*\d*)*)|
                                         (?:TSA-\d+)|
                                         (?:GTL\d{10})|
                                         (?:TKP\d{10})|
                                         (?:TG\d{10})|
                                         (\d{12})$
                                     )/mx;
    $receipt_id //= '';
    $receipt_id =~ s/\s+//g;
    log_warn "Can't figure out receipt ID from text" unless $receipt_id;

    my $courier;
    my $is_multi_courier;
    my $is_tokopedia;
    if ($receipt_id =~ /^JX/) {
        $courier = "J&T";
    } elsif ($receipt_id =~ /^GTL/) {
        $courier = "GTL";
    } elsif ($receipt_id =~ /^TG/) {
        $courier = "JNE";
    } elsif ($receipt_id =~ /^TSA/) {
        $courier = "AnterAja";
    } elsif ($receipt_id =~ /^TKP/) {
        $is_tokopedia = 1;
        if ($text_raw =~ /Multi\sCourier\s*\R\s*
                          ([^\n]+)\s*\R\s*          # kurir yg pickup
                          ([^\n]+)\s*\R\s*          # jenis layanan
                          ([^\n]+)\s*\R\s*          # kurir yg mengantar
                         /mx) {
            $is_multi_courier = 1;
            my ($courier1, $svc1, $courier2) = ($1, $2, $3);
            # pilih kurir yang pickup sebagai kurir
            if ($courier1 =~ /^JNE/) {
                $courier = "JNE";
            } elsif ($courier1 =~ /IDX/) {
                $courier = "IDX";
            }
        }
    } elsif ($receipt_id =~ /^[0-9]{12}$/) {
        $courier = 'J&T Cargo';
    }

    log_warn "Can't figure out courier from receipt ID '$receipt_id'" unless $courier;

    my ($order_id)       = $text_raw =~ m!^(?:TT )?order [1i]d\s*:\s*(\d{5,})!im or log_warn "$filename: Can't get order ID";
    $order_id //= '';
    #my $variant; # all tiktok orders are using J&T, so no variant here
    my $order_date; $text_raw =~ /\bShip\s*:\s*(\d\d)-(\d\d)-(\d\d\d\d)/ and $order_date = "$3-$2-$1" or log_warn "$filename: Can't extract order date (from Ship date)";

    my $has_sender_header = $text_raw =~ /^FROM\(SENDER\)$|
                                          ^Pengirim\s*:\s*/mx;
    my $has_recipient_header = $text_raw =~ /^TO\(ADDRESS\)$|
                                             ^Penerima\s*:\s*/mx;
    log_debug "has_sender_header? $has_sender_header, has_recipient_header? $has_recipient_header";

    # assume page2 if can't get courier & receipt id & no sender/recipient header
    my $is_first_page = 1;
    if (!$courier && !$receipt_id && !$has_sender_header && !$has_recipient_header) {
        log_warn "Can't get courier & receipt ID, probably page 2+?";
        $is_first_page = 0;
    }

    my ($customer_name, $customer_address, $customer_phone, $is_cod);
    if ($text_raw =~ /Penerima\s*: (.+?), \((\+\d+)\)([0-9*]+)\s*\R(.+?)(COD|cop|NON COD)/is) {
        $customer_name = $1;
        $customer_phone = "$2$3";
        $customer_address = $4;
        $is_cod = lc($5) eq 'cod' || lc($5) eq 'cop' ? 1:0; # OCR stuff

        $customer_address =~ s/\R/ /g;
        $customer_phone =~ s/\A\+620/+62/;

        log_trace "Got customer name: $customer_name, phone: $customer_phone, address: $customer_address, cod:$is_cod";
    } else {
        log_warn "$filename: Can't parse customer";
        $customer_address = "";
    }

    my ($customer_regency, $customer_city, $customer_province);
    if ($customer_address =~ /\A([A-Z ]+), ([A-Z .!-]+), ([A-Z !-]+), /) {
        $customer_province = $1;
        $customer_city = $2;
        $customer_regency = $3;
        for ($customer_province, $customer_city, $customer_regency) { s/!/I/g } # OCR
    } else {
        log_warn "$filename: Can't extract regency/city/province from address '$customer_address'";
    }

    my (@skus, @qtys);
    {
        my $items;

        if ($is_first_page) {
            ($items) = $text_raw =~ /^Product Name(.+)(?:Order ID)/ms
                or log_warn "$filename: Can't extract items (page 1)";
        } else {
            ($items) = $text_raw =~ /(.+)(?:Order ID)/ms
                or log_warn "$filename: Can't extract items (page 2+)";
        }
        log_trace "Items: <<$items>>";
        # cara lama, specific SKU
        while ($items =~ /(XDEF\S+) (\d+)/g) {
            push @skus, $1;
            push @qtys, $2;
        }
        if (!@skus) {
            log_trace "Extracting SKUs (variant 2) ...";
            if ($store eq 'berdikari') {
                # buang order ID yg terinclude, bisa menyebabkan salah terdeteksi sebagai quantity
                $items =~ s/\d{18}+//g;

                # buang penyebab false positive, e.g. prefiks awal "[BUNDEL 2 BOTOL]"
                $items =~ s/^\[[^\]]+\]\s*//gm;

                # buang penyebab false positive, e.g. "isi 24"
                $items =~ s/isi \s+ \d+\s*$//gmx;
                log_trace "Items (after processing 1): <<$items>>";

                while ($items =~ /\[([A-Z0-9. ]+)\]/g) {
                    next if $1 eq 'B1G1'; # false positive, don't know why it is printed in the SKU, e.g. in resi-tiktokshop-20221112-2.yuliani.ocrmypdf
                    push @skus, _strip_ws($1);
                }
                while ($items =~ / (\d+)$/mg) {
                    push @qtys, $1;
                }
            } elsif ($store eq 'goday') {
                # buang penyebab false positive, e.g. 20g x 24
                $items =~ s/\d+\s*g \s* x \s* \d+\s*$//gmx;
                log_trace "Items (after processing 1): <<$items>>";

                while ($items =~ m!^([A-Z]*-\s*[A-Z]*/\d+)!mgs) {
                    push @skus, _strip_ws($1);
                }
                while ($items =~ / (\d+)$/mg) {
                    push @qtys, $1;
                }
            }
        }
        if (!@skus) {
            log_trace "Extracting SKUs (variant 3) ...";
            while ($items =~ /((?:\d+x)?(?:[A-Z]+[A-Z0-9.]*)(?:x\d+)?)\s+(\d+)$/gm) {
                push @skus, $1;
                push @qtys, $2;
            }
        }

        if (@skus) {
            log_trace "Found %d SKUs: %s", scalar(@skus), \@skus;
            log_trace "Found %d Qtys: %s", scalar(@qtys), \@qtys;
        } else {
            #log_warn "$filename: Can't find any SKUs";
            #log_info "Assuming it's XDEF1 \@1pcs";
            #@skus = ("XDEF1");
            #@qtys = (1);
            return [500, "Can't find any SKUs for first page"] if $is_first_page;
        }
    }

    my $receipt_items = convert_skus_qtys_to_hashref(\@skus, \@qtys);

    my $wh_items = convert_receipt_items_to_warehouse_items(
        receipt_items => $receipt_items,
        store => $store,
    );

    my $res_check = check_skus(wh_items => $wh_items, store => $store, delete_unknown_skus => $delete_unknown_skus);
    return $res_check unless $res_check->[0] == 200;

    my $gift_pcs = {};
    my $sample_pcs = {};
    my $etc_pcs = {};

    my $res_encode = encode_items_str(
        items => $wh_items,
        gift_pcs => $gift_pcs,
        sample_pcs => $sample_pcs,
        etc_pcs => $etc_pcs,
    );
    die "Can't encode items: $res_encode->[0] - $res_encode->[1]" unless $res_encode->[0] == 200;

    my $res_sc = handle_special_codes(
        items => $wh_items,
        gift_pcs => $gift_pcs,
        sample_pcs => $sample_pcs,
        etc_pcs => $etc_pcs,
        text => $text_raw,
        text_raw => $text_raw,
    );
    die "Can't handle special codes: $res_sc->[0] - $res_sc->[1]" unless $res_sc->[0] == 200;
    my $promo_code = $res_sc->[2];

    [200, "OK", {
        is_first_page => $is_first_page,
        receipt_id => $receipt_id,
        courier => $courier,
        order_id => $order_id,
        order_date => $order_date,
        customer_name => $customer_name,
        customer_address => $customer_address,
        customer_regency => $customer_regency,
        customer_city => $customer_city,
        customer_province => $customer_province,
        customer_phone => $customer_phone,
        is_cod => $is_cod,
        receipt_items => $receipt_items,
        wh_items => $wh_items,
        gift_pcs => $gift_pcs,
        sample_pcs => $sample_pcs,
        etc_pcs => $etc_pcs,
        promo_code => $promo_code,
        text => $text_raw,
        text_raw => $text_raw,
    }];
}

$SPEC{rename_delivery_receipt} = {
    v => 1.1,
    summary => "Rename Berdikari's TiktokShop delivery receipt to a standardized format",
    args => {
        filename => {
            schema => 'filename::exists*',
            req => 1,
            pos => 0,
        },
        %argspecopt_store,
        %argspecopt_receipt_type,
        %argspecopt_delete_unknown_skus,
    },
    features => {
        dry_run => 1,
    },
};
sub rename_delivery_receipt {
    my %args = @_;
    my $filename = $args{filename};
    my $store = $args{store} // 'berdikari';
    my $receipt_type = $args{receipt_type} // 'sale';
    my $delete_unknown_skus = $args{delete_unknown_skus};

    my $res = parse_delivery_receipt(
        filename => $filename,
        store => $store,
        delete_unknown_skus => $delete_unknown_skus,
    );
    return [500, "Can't parse delivery receipt '$filename': $res->[0] - $res->[1]"]
        unless $res->[0] == 200;

    my $new_filename = receipt_filename(
        receipt_type => $receipt_type,
        marketplace => "tiktokshop",
        is_first_page => $res->[2]{is_first_page},
        store => $store,
        order_id => $res->[2]{order_id},
        number => $res->[2]{receipt_id},
        courier => $res->[2]{courier},
        customer => $res->[2]{customer_name},
        receipt_items => $res->[2]{receipt_items},
        wh_items => $res->[2]{wh_items},
        gift_pcs => $res->[2]{gift_pcs},
        sample_pcs => $res->[2]{sample_pcs},
        etc_pcs => $res->[2]{etc_pcs},
        promo_code => $res->[2]{promo_code},
    );

    (my $ocr_filename     = $filename)     =~ s/\.pdf\z/\.ocrmypdf.pdf/;
    (my $ocr_new_filename = $new_filename) =~ s/\.pdf\z/\.ocrmypdf.pdf/;

    if ($args{-dry_run}) {
        log_info "[DRY RUN] Renaming %s to %s ...", $filename, $new_filename;
        log_info "[DRY RUN] Renaming %s to %s ...", $ocr_filename, $ocr_new_filename if -e $ocr_filename;
        [200, "OK (dry-run)"];
    } else {
        log_info "Renaming %s to %s ...", $filename, $new_filename;
        rename $filename, $new_filename or return [500, "Can't rename $filename to $new_filename: $!"];
        if (-e $ocr_filename) {
            log_info "Renaming %s to %s ...", $ocr_filename, $ocr_new_filename;
            rename $ocr_filename, $ocr_new_filename or warn "Can't rename $ocr_filename to $ocr_new_filename: $!";
        }
        [200, "OK"];
    }
}

$SPEC{rename_delivery_receipts} = {
    v => 1.1,
    summary => "Rename Berdikari's TiktokShop delivery receipts to a standardized format",
    args => {
        filenames => {
            schema => ['array*', of=>'filename::exists*'],
            req => 1,
            pos => 0,
            slurpy => 1,
        },
        %argspecopt_store,
        %argspecopt_receipt_type,
    },
    features => {
        dry_run => 1,
    },
};
sub rename_delivery_receipts {
    my %args = @_;
    my $filenames = $args{filenames};
    my $store = $args{store} // 'berdikari';

    my $res = envresmulti();
    for my $filename (@$filenames) {
        log_info "Processing file %s ...", $filename;
        my $fres = rename_delivery_receipt(
            filename => $filename,
            receipt_type => $args{receipt_type},
            store => $args{store},
            delete_unknown_skus => $args{delete_unknown_skus},
            -dry_run => $args{-dry_run},
        );
        $res->add_result($fres->[0], $fres->[1], {item_id => $filename});
    }
    $res->as_struct;
}

$SPEC{parse_delivery_receipts_to_csv} = {
    v => 1.1,
    summary => "Parse Berdikari's TiktokShop delivery receipts to CSV",
    args => {
        filenames => {
            schema => ['array*', of=>'filename::exists*'],
            req => 1,
            pos => 0,
            slurpy => 1,
        },
        %argspecopt_store,
        %argspecopt_delete_unknown_skus,
    },
    features => {
        dry_run => 1,
    },
};
sub parse_delivery_receipts_to_csv {
    my %args = @_;
    my $filenames = $args{filenames};

    print "tanggal,order_id,internal_order_id,customer_name,customer_phone,customer_province,customer_city,customer_regency,sku,quantity,unit,is_self_order,is_cod\n";
    for my $filename (@$filenames) {
        if ($filename =~ /\.ocrmypdf\.pdf\z/i) {
            log_info "Skipping $filename";
            next;
        }
        log_info "Processing file %s ...", $filename;
        my $fres = parse_delivery_receipt(
            filename => $filename,
            store => $args{store},
            delete_unknown_skus => $args{delete_unknown_skus},
        );
        die "FATAL: Can't parse receipt '$filename': $fres->[0] - $fres->[1]" unless $fres->[0] == 200;
        my $r = $fres->[2]; # r=receipt
        my $line = 0;
        for my $item (@{ $r->{items} }) {
            $line++;
            if ($line == 1) { print qq($r->{order_date},$r->{order_id},$r->{order_id},"$r->{customer_name}",$r->{customer_phone},$r->{customer_province},$r->{customer_city},$r->{customer_regency}) }
            else            { print qq($r->{order_date},$r->{order_id} (line $line),$r->{order_id},,,,,) }
            print ",", $item->{sku}, ",", $item->{quantity}, ",no,", ($r->{is_cod} ? "yes":"no");
            print "\n";
        }
    }
    [200];
}

1;
# ABSTRACT: Rename Berdikari's TiktokShop delivery receipts to a standardized format

__END__

=pod

=encoding UTF-8

=head1 NAME

Berdikari::Parse::DeliveryReceipt::TiktokShop - Rename Berdikari's TiktokShop delivery receipts to a standardized format

=head1 VERSION

This document describes version 0.029 of Berdikari::Parse::DeliveryReceipt::TiktokShop (from Perl distribution Berdikari-Parse-DeliveryReceipt-TiktokShop), released on 2026-05-25.

=head1 FUNCTIONS


=head2 parse_delivery_receipt

Usage:

 parse_delivery_receipt(%args) -> [$status_code, $reason, $payload, \%result_meta]

Parse TiktokShop delivery receipt (resi pengiriman).

For older versions of receipts: Because TiktokShop's delivery receipt needs to
be OCR'ed first, this utility will first produce a C<*.ocrmypdf.pdf> file if it
does not yet exist.

For newer versions: by default, no OCR-ing is done because it's no longer
needed.

This function is not exported.

Arguments ('*' denotes required arguments):

=over 4

=item * B<delete_unknown_skus> => I<bool>

(No description)

=item * B<filename>* => I<filename::exists>

(No description)

=item * B<ocr> => I<bool>

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 parse_delivery_receipts_to_csv

Usage:

 parse_delivery_receipts_to_csv(%args) -> [$status_code, $reason, $payload, \%result_meta]

Parse Berdikari's TiktokShop delivery receipts to CSV.

This function is not exported.

This function supports dry-run operation.


Arguments ('*' denotes required arguments):

=over 4

=item * B<delete_unknown_skus> => I<bool>

(No description)

=item * B<filenames>* => I<array[filename::exists]>

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Special arguments:

=over 4

=item * B<-dry_run> => I<bool>

Pass -dry_run=E<gt>1 to enable simulation mode.

=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 rename_delivery_receipt

Usage:

 rename_delivery_receipt(%args) -> [$status_code, $reason, $payload, \%result_meta]

Rename Berdikari's TiktokShop delivery receipt to a standardized format.

This function is not exported.

This function supports dry-run operation.


Arguments ('*' denotes required arguments):

=over 4

=item * B<delete_unknown_skus> => I<bool>

(No description)

=item * B<filename>* => I<filename::exists>

(No description)

=item * B<receipt_type> => I<str> (default: "sale")

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Special arguments:

=over 4

=item * B<-dry_run> => I<bool>

Pass -dry_run=E<gt>1 to enable simulation mode.

=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 rename_delivery_receipts

Usage:

 rename_delivery_receipts(%args) -> [$status_code, $reason, $payload, \%result_meta]

Rename Berdikari's TiktokShop delivery receipts to a standardized format.

This function is not exported.

This function supports dry-run operation.


Arguments ('*' denotes required arguments):

=over 4

=item * B<filenames>* => I<array[filename::exists]>

(No description)

=item * B<receipt_type> => I<str> (default: "sale")

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Special arguments:

=over 4

=item * B<-dry_run> => I<bool>

Pass -dry_run=E<gt>1 to enable simulation mode.

=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)

=head1 AUTHOR

Steven Haryanto

=head1 CONTRIBUTORS

=for stopwords Steven Haryanto

=over 4

=item *

Steven Haryanto <stevenharyanto@gmail.com>

=item *

Steven Haryanto <stevenptbtc@gmail.com>

=back

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2026, 2025 by Steven Haryanto.  No
license is granted to other entities.

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=cut
